<head>
<meta http-equiv="Contenct-Type" content="text/html; charset=iso-8859-1" />
<title>Data Customer</title>
</head>
<body><CENTER>
	<table width="800" height="350" border="1" align="center" bgcolor="#00FF99">
	<tr>
		<td><table width="500" height="50" border="1" align="center" bgcolor="red">
	</tr><center><b>
<b><h3>PT.SISTEM INFORMASi</h3>
JL.RAYA SERANG KM.10 BITUNG TANGERANG</b></center>
<hr>
<br><br><b>
	<td align="center" width="400">INPUT DATA CUSTOMER</td>
	<form method="post" action="koneksicustomer.php">
	</table>

<table width="500" border="1" align="center" bgcolor="white">
	<tr>
		<td width="300">Kode customer</td>
		<td><input name="txtkdcustomer" type="text"id="txtkdcustomer" size="5"/></td>
	</tr>

	<tr>
		<td>Nama Customer</td>
		<td><input name="txtnmcustomer" type="text"id="txtnmcustomer" size="25"/></td>
	</tr>
    <tr>
		<td>Telepon</td>
		<td><input name="txttlp" type="text"id="txttlp" size="15"/></td>
	</tr>
	<tr>
		<td>Email</td>
		<td><input name="txtemail" type="text"id="txtemail" size="40"/></td>
	</tr>
	<tr>
		<td>Alamat</td>
		<td><input name="txtalamat" type="text"id="txtalamat" size="5"/></td>
	</tr>

	<tr><CENTER>
		<td colspan="2"><form id="form5" name="form5" method="post" action="">
			<input name="BtnSave" type="submit" id="BtnSave" value="save" />
			<input name="BtnBatal" type="reset" id="BtnBtal" value="cancel" />
	</form>
</td>

<tr>
</tr>
</table>

